package fantasymanager.ui;

public interface ConfirmDialogListener {
	void yes();
	
	void no();
}
